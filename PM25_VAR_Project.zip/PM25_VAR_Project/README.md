# PM2.5 Prediction Using Vector Autoregression (VAR)

## Project files
- `Data.xlsx`: input spreadsheet supplied for this project.
- `pm25_var.py`: end-to-end preprocessing, BIC lag selection, VAR fitting, prediction, metrics, and plotting.
- `VAR_PM25_Results.xlsx`: actual and predicted PM2.5 values on the test set.
- `VAR_PM25_Metrics.csv`: evaluation metrics.
- `VAR_PM25_Prediction.png`: actual-vs-predicted plot.
- `VAR_PM25_Errors.png`: prediction error plot.
- `requirements.txt`: required Python packages.

## Run on Windows
1. Install Python 3.10+.
2. Open Command Prompt in this folder.
3. Run:
   ```bash
   python -m pip install -r requirements.txt
   python pm25_var.py
   ```

## Method
1. Select `PM2.5`, `RH`, `WD`, `SR`, `BP`, `AT`.
2. Convert values to numeric and linearly interpolate missing entries.
3. Split chronologically into 80% training and 20% testing.
4. Select VAR lag order using BIC on the training set (up to 10 lags).
5. Fit VAR and perform rolling one-step-ahead predictions using fixed fitted coefficients.
6. Evaluate with MSE, MAPE, RMSE, and R-squared.

## Important assumptions and limitations
- The workbook has no timestamp column. The script assumes rows are already in chronological order; verify this before interpreting results.
- `SR` has missing values; interpolation is used.
- Wind direction is circular, but this baseline treats it as a numeric degree value. A stronger study could replace it with sine/cosine features.
- These are one-step-ahead rolling forecasts: previous actual test observations are available at each step. This is not a fully open-loop multi-step forecast.
- VAR generally assumes stationary series. Check stationarity and consider differencing/transformations as an improvement.
- The first GitHub repository used as workflow inspiration uses naive/Ridge/LSTM models, not VAR. This project adapts the chronological split, preprocessing, evaluation and plotting workflow while implementing VAR to meet the assignment requirement.
