"""
PM2.5 forecasting using Vector Autoregression (VAR)
Input: Data.xlsx
Target: PM2.5
Variables: PM2.5, RH, WD, SR, BP, AT
Evaluation: MSE, MAPE, RMSE, R-squared
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.api import VAR
from sklearn.metrics import (
    mean_squared_error,
    mean_absolute_percentage_error,
    r2_score,
)

FILE_PATH = "Data.xlsx"
COLUMNS = ["PM2.5", "RH", "WD", "SR", "BP", "AT"]
TEST_FRACTION = 0.20
MAX_LAGS = 10

def main():
    # Load and select the project columns; ignore extra blank Excel columns.
    raw = pd.read_excel(FILE_PATH)
    missing_columns = [c for c in COLUMNS if c not in raw.columns]
    if missing_columns:
        raise ValueError(f"Missing required columns: {missing_columns}")

    data = raw[COLUMNS].apply(pd.to_numeric, errors="coerce")

    # Interpolate missing values in row order. This assumes rows are chronological.
    data = data.interpolate(method="linear", limit_direction="both").dropna()
    data = data.reset_index(drop=True)

    if len(data) <= MAX_LAGS + 10:
        raise ValueError("Not enough rows for VAR lag selection.")

    split = int(len(data) * (1 - TEST_FRACTION))
    train = data.iloc[:split].copy()
    test = data.iloc[split:].copy()

    print(f"Rows after preprocessing: {len(data)}")
    print(f"Training rows: {len(train)}")
    print(f"Testing rows: {len(test)}")
    print("\nMissing values after preprocessing:")
    print(data.isna().sum())

    # Select the lag order with BIC using only training data.
    var_model = VAR(train)
    order_results = var_model.select_order(maxlags=MAX_LAGS)
    print("\nLag order selection:")
    print(order_results.summary())
    lag = order_results.selected_orders["bic"]
    if lag is None or lag < 1:
        lag = 1
    print(f"\nSelected lag by BIC: {lag}")

    fitted = var_model.fit(lag)
    print(f"VAR model stable: {fitted.is_stable()}")
    print("\nModel summary:")
    print(fitted.summary())

    # Rolling one-step-ahead evaluation with fixed coefficients.
    # At each test step, previous actual observations are available.
    predictions = []
    for i in range(len(test)):
        history = data.iloc[:split + i]
        forecast = fitted.forecast(
            y=history.to_numpy()[-lag:],
            steps=1
        )
        predictions.append(forecast[0, 0])

    actual = test["PM2.5"].to_numpy()
    predicted = np.asarray(predictions)

    mse = mean_squared_error(actual, predicted)
    mape = mean_absolute_percentage_error(actual, predicted) * 100
    rmse = np.sqrt(mse)
    r2 = r2_score(actual, predicted)

    metrics = pd.DataFrame({
        "Metric": ["MSE", "MAPE (%)", "RMSE", "R-squared"],
        "Value": [mse, mape, rmse, r2]
    })
    print("\n===== TEST RESULTS =====")
    print(metrics.to_string(index=False, formatters={"Value": "{:.6f}".format}))

    results = pd.DataFrame({
        "Test_Row_Number": np.arange(split + 1, split + len(test) + 1),
        "Actual_PM2.5": actual,
        "Predicted_PM2.5": predicted,
        "Error_Actual_Minus_Predicted": actual - predicted
    })
    results.to_excel("VAR_PM25_Results.xlsx", index=False)
    metrics.to_csv("VAR_PM25_Metrics.csv", index=False)

    # Plot 1: actual vs predicted.
    plt.figure(figsize=(12, 5))
    plt.plot(actual, label="Actual PM2.5", linewidth=1.8)
    plt.plot(predicted, label="Predicted PM2.5", linewidth=1.5)
    plt.title("Actual vs Predicted PM2.5 (VAR)")
    plt.xlabel("Test observation")
    plt.ylabel("PM2.5 concentration")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("VAR_PM25_Prediction.png", dpi=300)
    plt.close()

    # Plot 2: residual/error diagnostic.
    errors = actual - predicted
    plt.figure(figsize=(12, 4))
    plt.plot(errors, label="Actual - predicted", linewidth=1)
    plt.axhline(0, linestyle="--")
    plt.title("VAR PM2.5 Forecast Errors")
    plt.xlabel("Test observation")
    plt.ylabel("Prediction error")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig("VAR_PM25_Errors.png", dpi=300)
    plt.close()

    print("\nSaved: VAR_PM25_Results.xlsx")
    print("Saved: VAR_PM25_Metrics.csv")
    print("Saved: VAR_PM25_Prediction.png")
    print("Saved: VAR_PM25_Errors.png")

if __name__ == "__main__":
    main()
